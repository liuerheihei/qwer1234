package com.it.edu.queue;

/**
 * @description: 球
 * @author: 图灵学院-杨过
 * QQ：692927914
 */
public class Ball {
    /**
     * 编号
     */
    private String number ;
    /**
     * 颜色
     */
    private String color ;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
