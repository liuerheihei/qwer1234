package com.tuling.spring;/**
 * Created by Administrator on 2018/8/26.
 */

/**
 * @author Tommy
 *         Created by Tommy on 2018/8/26
 **/
public class Hi {

    public Hi() {
        System.out.println("new hi");
    }

    public void sayHi() {
        System.out.println("hi");
    }
}
