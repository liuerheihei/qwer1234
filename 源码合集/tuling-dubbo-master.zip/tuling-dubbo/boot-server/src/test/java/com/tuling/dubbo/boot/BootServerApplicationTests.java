package com.tuling.dubbo.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
