package com.tuling.client;

/**
 * @author Tommy
 * Created by Tommy on 2019/12/13
 **/
public interface OrderService {
    String getOrder();
}
