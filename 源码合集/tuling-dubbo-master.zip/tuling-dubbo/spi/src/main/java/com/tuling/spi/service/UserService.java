package com.tuling.spi.service;

public interface UserService {
    public String getName(int id);
}
