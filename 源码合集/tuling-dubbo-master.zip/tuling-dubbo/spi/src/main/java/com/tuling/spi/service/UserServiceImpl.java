package com.tuling.spi.service;

/**
 * @author Tommy
 * Created by Tommy on 2019/12/1
 **/
public class UserServiceImpl implements UserService {
    @Override
    public String getName(int id) {
        return "luban good ";
    }
}
