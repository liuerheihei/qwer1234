package com.jiagouedu.proxy;

public interface Subject
{

    public void hello(String str);
}