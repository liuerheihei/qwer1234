package com.tuling.zk.dubbo;

/**
 * @author Tommy
 * Created by Tommy on 2019/10/8
 **/
public interface UserService {
    UserVo getUser(Integer id);
}
