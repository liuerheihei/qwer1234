'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://120.27.63.9:8080"'
}
