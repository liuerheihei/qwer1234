package com.tuling;

/**
 * Created by smlz on 2019/5/21.
 */
public class Car {

    private String carName;

    private String carBrand;

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand;
    }
}
