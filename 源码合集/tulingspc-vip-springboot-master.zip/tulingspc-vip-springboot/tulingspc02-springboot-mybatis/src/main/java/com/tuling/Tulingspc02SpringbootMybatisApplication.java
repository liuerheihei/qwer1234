package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingspc02SpringbootMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingspc02SpringbootMybatisApplication.class, args);
	}

}
