package com.tuling.compent;

/**
 * Created by smlz on 2019/3/28.
 */
public class TulingDao {

    public TulingDao() {
        System.out.println("我是通过ImportBeanDefinitionRegistrar 导入进来的组件");
    }
}
