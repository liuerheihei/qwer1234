package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingspc01SpringbootQksStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingspc01SpringbootQksStudyApplication.class, args);
	}

}
