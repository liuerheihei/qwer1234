package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * Created by smlz on 2019/7/12.
 */
@SpringBootApplication
public class MainClassStart {

    public static void main(String[] args) {
        SpringApplication.run(MainClassStart.class,args);
    }
}
