package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingspc02SpringbootRabbitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingspc02SpringbootRabbitmqApplication.class, args);
	}

}
