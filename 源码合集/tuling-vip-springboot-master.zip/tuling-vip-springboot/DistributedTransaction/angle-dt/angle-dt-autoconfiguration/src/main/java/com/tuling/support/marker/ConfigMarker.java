package com.tuling.support.marker;

/**
 * 条件激活bean
 * Created by smlz on 2019/7/30.
 */
public class ConfigMarker {
}
