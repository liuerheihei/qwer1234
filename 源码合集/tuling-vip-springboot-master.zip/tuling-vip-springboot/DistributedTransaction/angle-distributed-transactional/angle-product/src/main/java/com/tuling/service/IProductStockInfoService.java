package com.tuling.service;

/**
 * Created by smlz on 2019/7/28.
 */
public interface IProductStockInfoService {

    void updateProductStock(String productId);
}
