package com.tuling.busi.service;

import com.tuling.busi.entity.OrderInfo;

/**
 * Created by smlz on 2019/7/25.
 */
public interface IOrderInfoService {

    void saveOrder(OrderInfo order);
}
