package com.tuling.multidatasource.enumuration;

/**
 * Created by smlz on 2019/4/17.
 */
public enum  RoutingStategyEnum {

    /**
     * 多库 多表策略
     */
    ROUTING_DS_TABLE_STATEGY,

    /**
     * 多库 一表策略
     */
    ROUTGING_DS_STATEGY,

    /**
     * 一库多表策略
     */
    ROUTGIN_TABLE_STATEGY;
}
