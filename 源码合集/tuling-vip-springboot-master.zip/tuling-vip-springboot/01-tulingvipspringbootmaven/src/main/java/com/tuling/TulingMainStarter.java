package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by smlz on 2019/3/19.
 */
@SpringBootApplication
public class TulingMainStarter {

    public static void main(String[] args) {
        SpringApplication.run(TulingMainStarter.class,args);
    }
}
