package com.tuling.condition;

/**
 * Created by smlz on 2019/3/28.
 */
public class TulingAspect {

    public TulingAspect() {
        System.out.println("我是TulingAspect..................");
    }
}
