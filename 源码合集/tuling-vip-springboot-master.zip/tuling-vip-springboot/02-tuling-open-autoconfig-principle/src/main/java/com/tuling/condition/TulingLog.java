package com.tuling.condition;

/**
 * Created by smlz on 2019/3/28.
 */
public class TulingLog {

    public TulingLog() {
        System.out.println("我是TulingLog。。。。。。。我依赖TulingAspect");
    }
}
