package com.tuling.compent;

/**
 * Created by smlz on 2019/3/28.
 */
public class TulingServiceImpl {

    public TulingServiceImpl(){
        System.out.println("我是通过ImportSelector组件导入进来的组件");
    }
}
