package java.lang;

/**
 * @author Tommy
 * Created by Tommy on 2019/9/4
 **/
public class String1 {
    public void sayHello() {

    }
}
