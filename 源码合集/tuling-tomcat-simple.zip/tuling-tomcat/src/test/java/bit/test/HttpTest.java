package bit.test;

import java.io.IOException;

/**
 * Created by Tommy on 2018/1/30.
 */
public class HttpTest {

    public static void main(String[] args) throws IOException {
       /* String path = "E:\\VMware\\CentOS 64 位-56cf01f2.vmem";
        File f=new File(path);
        InputStream inputStream=new FileInputStream(f);
        byte[] b = new byte[8192*2];
        int size=0;
        int count=0;
        Socket socket=null;
        inputStream = socket.getInputStream();
        // Scoket1 流 TCP协议 写内核 ==》内存
        //File: CPU 向操作系统发起 读取 指令 。从硬盘读到应用内存。
        //Scoket:CPU 向操作系统发起 读取 指令。基于TCP连接 把流写到内核在写到内存。
        while((size=inputStream.read(b))>=0){
        	count+=size;
        }
        System.out.println(count);*/
    }
}

