package com.tl.it.edu.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @author ：图灵-杨过
 * @date：2019/11/11
 * @version: V1.0
 * @slogan: 天下风云出我辈，一入代码岁月催
 * @description :
 */
@Mapper
public interface UserMapper {
}
