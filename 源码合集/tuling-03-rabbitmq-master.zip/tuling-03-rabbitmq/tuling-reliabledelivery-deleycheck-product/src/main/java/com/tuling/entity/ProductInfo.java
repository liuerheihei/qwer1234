package com.tuling.entity;

import lombok.Data;

/**
 * Created by smlz on 2019/10/13.
 */
@Data
public class ProductInfo {

    private Integer productNo;

    private String productName;

    private String productNum;
}
