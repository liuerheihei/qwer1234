package com.tuling.mapper;


/**
 * Created by smlz on 2019/10/13.
 */
public interface ProductInfoMapper {

    int updateProductStoreById(Integer productId);

}


