package com.tuling.service;


import com.tuling.bo.MsgTxtBo;

/**
 * Created by smlz on 2019/10/13.
 */
public interface IProductService {

    boolean updateProductStore(MsgTxtBo msgTxtBo);

}
