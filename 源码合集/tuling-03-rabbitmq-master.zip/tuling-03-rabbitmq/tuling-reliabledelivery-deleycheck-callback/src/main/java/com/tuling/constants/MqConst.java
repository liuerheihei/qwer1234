package com.tuling.constants;

/**
* @vlog: 高于生活，源于生活
* @desc: 类的描述:
* @author: smlz
* @createDate: 2019/10/11 16:41
* @version: 1.0
*/
public class MqConst {

    public static final Integer MAX_RETRY_COUNT = 5;

    public static final String ORDER_TO_PRODUCT_DELAY_QUEUE_NAME = "order-to-product.delayqueue";

}
